import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluentui_icons/fluentui_icons.dart';
import 'package:login/screens/profile_screen.dart';
import 'package:login/screens/search_screen.dart';
import 'package:login/screens/ticket_screens.dart';
import 'package:login/welcome_page.dart';

import 'home_screen.dart';

class BottomBar extends StatefulWidget {
  const BottomBar({Key? key}) : super(key: key);

  @override
  State<BottomBar> createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  int _selectedIndex=0;
  static final List<Widget>_widgetOption=<Widget>[
    const HomeScreen(),
    const SearchScreen(),
    const TicketScreen(),
    const ProfileScreen(),
    WelcomePage(email: "",),

  ];

  void _onItemTapped(int index){
    setState(() {
      _selectedIndex=index;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body:Center(
        child:_widgetOption[_selectedIndex],
      ),

      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          showSelectedLabels:false,
          showUnselectedLabels:false,
          selectedItemColor: Colors.red,
          unselectedItemColor: Colors.black,
          items:const [
            BottomNavigationBarItem(icon: Icon(FluentSystemIcons.ic_fluent_home_regular),
                activeIcon: Icon(FluentSystemIcons.ic_fluent_home_filled),
                label: "home"),
            BottomNavigationBarItem(icon: Icon(FluentSystemIcons.ic_fluent_search_filled),label: "search"),
            BottomNavigationBarItem(icon: Icon(FluentSystemIcons.ic_fluent_ticket_filled),label: "ticket"),
            BottomNavigationBarItem(icon: Icon(FluentSystemIcons.ic_fluent_person_filled),label: "profile"),
            BottomNavigationBarItem(icon: Icon(FluentSystemIcons.ic_fluent_sign_out_filled),label: "signout"),
          ]
      ),
    );

  }
}
