import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:login/screens/bottom_bar.dart';
import 'package:login/screens/profile_screen.dart';
import 'package:login/utils/app_layout.dart';
import 'package:login/utils/app_styles.dart';
import 'package:gap/gap.dart';
import 'package:barcode_widget/barcode_widget.dart';

class CheckOutPage extends StatelessWidget {
  const CheckOutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double w = MediaQuery.of(context).size.width;
    double h = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Column(
        children: [
          Container(
            width: w,
            height: h*0.4,
            decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage("img/loginimg.png"),
                    fit: BoxFit.cover
                )
            ),

          ),
          Container(
            margin: EdgeInsets.all(AppLayout.getWidth(25)),
            padding: EdgeInsets.all(AppLayout.getWidth(15)),
            width: AppLayout.getWidth(300),
            color: Colors.white,

            child: Column(
              children: [
                Container(
                  height:50,
                  width: 50,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      image:const DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage("img/greentk.png"))
                  ),
                ),
                Gap(AppLayout.getWidth(40)),
                Center(
                  child: Text("Your Ticket has been Booked",style: Styles.headLineStyle2.copyWith(fontSize: 25),textAlign: TextAlign.center),
                ),
                Container(
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(AppLayout.getHeight(21)),
                          bottomLeft: Radius.circular(AppLayout.getHeight(21))
                      )
                  ),
                  margin: EdgeInsets.only(left:AppLayout.getHeight(15),right:AppLayout.getHeight(15) ),
                  padding: EdgeInsets.only(top: AppLayout.getHeight(20),bottom: AppLayout.getHeight(20)),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: AppLayout.getWidth(15)),
                    child: ClipRRect(
                      borderRadius:BorderRadius.circular(AppLayout.getHeight(14)),
                      child: BarcodeWidget(
                        barcode: Barcode.code128(),
                        data: 'https://github.com/martinovovo',
                        drawText: false,
                        color: Styles.textColor,
                        width: double.infinity,
                        height: 70,
                      ),
                    ),
                  ),
                ),
            Center(
              child:
              RichText(text: TextSpan(
                recognizer: TapGestureRecognizer()..onTap=()=>Get.to(BottomBar()),
                text: "see more details",
                style: TextStyle(
                    color: Colors.lightBlueAccent,
                    fontSize: 20
                ),
              )),//Text("Find Tickets",style: Styles.headLineStyle3.copyWith(color: Colors.white),) ,
            ),
              ],
            ),

          )
        ],
      ),
    );
  }
}
