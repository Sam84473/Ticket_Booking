import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:login/screens/ticket_screens.dart';

import '../utils/app_layout.dart';
import '../utils/app_styles.dart';
import '../widgets/double_text_widget.dart';
import '../widgets/icon_text_widget.dart';
import '../widgets/tickets_tabs.dart';
import 'checkout_page.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = AppLayout.getSize(context);
    return Scaffold(
      backgroundColor: Styles.bgColor,
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: AppLayout.getWidth(20),vertical:AppLayout.getHeight(20) ),
        children: [
          Gap(AppLayout.getHeight(40)),
          Text("What Are\nYou Looking For?",style: Styles.headLineStyle1.copyWith(fontSize: AppLayout.getWidth(35)),),
          Gap(AppLayout.getHeight(20)),
          //Airline and hotel tab
          const AppTicketsTabs(firstTab: "Airline Tickets",secondTab: "hotels",),
          Gap(AppLayout.getHeight(25)),
          //departure
          const AppIconText(icon:Icons.flight_takeoff_rounded,text:"Departure",),
          Gap(AppLayout.getHeight(15)),
          //arrival
          const AppIconText(icon:Icons.flight_land_rounded,text:"Arrival",),
          Gap(AppLayout.getHeight(25)),
          //FindTickets
          Container(
            padding: EdgeInsets.symmetric(vertical: AppLayout.getHeight(18),horizontal: AppLayout.getWidth(15)),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppLayout.getWidth(10)),
              color: Colors.redAccent,
                boxShadow: [
                  BoxShadow(
                      blurRadius: 10,
                      spreadRadius: 7,
                      offset: Offset(1, 1),
                      color: Colors.black.withOpacity(0.4)
                  )
                ]
            ),
            child: Center(
              child:
              RichText(text: TextSpan(
                recognizer: TapGestureRecognizer()..onTap=()=>Get.to(TicketScreen()),
                text: "Find Tickets",
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold
                ),
              )),//Text("Find Tickets",style: Styles.headLineStyle3.copyWith(color: Colors.white),) ,
            ),
          ),
          Gap(AppLayout.getHeight(40)),
          //UpcomingFlight and ViewAll
          const AppDoubleTextWidget(text: "Upcoming Flight",smallText: "View all",),
          Gap(AppLayout.getHeight(20)),
          Row(
            children: [
              //whitebox containg image and text
              Container(
                height: AppLayout.getHeight(425),
                width: size.width*0.42,
                padding: EdgeInsets.symmetric(vertical: AppLayout.getHeight(15),horizontal: AppLayout.getWidth(15)),
                decoration:  BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(AppLayout.getHeight(20)),
                    boxShadow:
                    [
                      BoxShadow(
                        color: Colors.grey.shade200,
                        blurRadius: 1,
                        spreadRadius: 1,
                      )
                    ]
                ),
                child: Column(
                  children: [
                    Container(
                      height: AppLayout.getHeight(198),
                      decoration:  BoxDecoration(
                          borderRadius: BorderRadius.circular(AppLayout.getHeight(12)),
                          image: const DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("img/sit.png"))
                      ),
                    ),
                    Gap(AppLayout.getHeight(15)),
                    Text("20% Discount on early booking of this flight.Don't miss out this chance",style: Styles.headLineStyle3.copyWith(color: Colors.black)),
                  ],
                ),
              ),
              const Spacer(),
              Column(
                children: [
                  Stack(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(vertical: AppLayout.getHeight(15),horizontal: AppLayout.getWidth(15)),
                        width: size.width*0.44,
                        height: AppLayout.getHeight(195),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade200,
                          borderRadius: BorderRadius.circular(AppLayout.getHeight(18)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Discount\nFor Survey",style: Styles.headLineStyle2.copyWith(fontWeight: FontWeight.bold,color: Colors.white),),
                            Gap(AppLayout.getHeight(10)),
                            Text("Take the survey about our service and get discount",style: Styles.headLineStyle2.copyWith(fontSize:18,fontWeight: FontWeight.w500,color: Colors.white),),
                          ],
                        ),
                      ),
                      Positioned(
                          right: -40,
                          top: -20,
                          child:  Container(
                            padding: EdgeInsets.all(AppLayout.getHeight(30)),
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(width: AppLayout.getWidth(18),color: Colors.lightBlue.shade500),
                                color: Colors.transparent
                            ),
                          ))
                    ],
                  ),
                  Gap(AppLayout.getHeight(20)),
                  Stack(
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(vertical: AppLayout.getHeight(15),horizontal: AppLayout.getWidth(15)),
                        width: size.width*0.44,
                        height: AppLayout.getHeight(195),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade400,
                          borderRadius: BorderRadius.circular(AppLayout.getHeight(18)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Discount\nFor Coupons",style: Styles.headLineStyle2.copyWith(fontWeight: FontWeight.bold,color: Colors.white),),
                            Gap(AppLayout.getHeight(10)),
                            Text("Use Coupons for various offers ",style: Styles.headLineStyle2.copyWith(fontSize:18,fontWeight: FontWeight.w500,color: Colors.white),),
                          ],
                        ),
                      ),
                      Positioned(
                          right: -50,
                          top: -20,
                          child:  Container(
                            padding: EdgeInsets.all(AppLayout.getHeight(30)),
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(width: AppLayout.getWidth(18),color: Colors.grey),
                                color: Colors.transparent
                            ),
                          ))
                    ],
                  ),


                ],
              )
            ],
          )

        ],
      ),
    );
  }
}
