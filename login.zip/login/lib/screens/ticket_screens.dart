import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:login/screens/ticket_view.dart';

import '../utils/app_info_list.dart';
import '../utils/app_layout.dart';
import '../utils/app_styles.dart';
import '../widgets/column_layout.dart';
import '../widgets/layout_builder_widget.dart';
import '../widgets/tickets_tabs.dart';
import 'package:barcode_widget/barcode_widget.dart';

import 'checkout_page.dart';

class TicketScreen extends StatelessWidget {
  const TicketScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = AppLayout.getSize(context);
    return Scaffold(
      backgroundColor: Styles.bgColor,
      body: Stack(children:[
        ListView(
          padding: EdgeInsets.symmetric(horizontal: AppLayout.getWidth(15),vertical: AppLayout.getHeight(15)),
          children: [
            Gap(AppLayout.getHeight(40)),
            Text("Tickets",style: Styles.headLineStyle1,),
            Gap(AppLayout.getHeight(20)),
            const AppTicketsTabs(firstTab:"Upcoming" ,secondTab: "Previous",),
            Gap(AppLayout.getHeight(20)),
            Container(
                padding: EdgeInsets.only(left: AppLayout.getHeight(15)),
                child : TicketView(ticket: ticketList[0],isColor: true,)
            ),
            SizedBox(height: 1,),
            Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: AppLayout.getHeight(15),vertical: AppLayout.getHeight(15)),
              margin:EdgeInsets.symmetric(horizontal: AppLayout.getHeight(15)),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children:  const [

                      AppColumnLayout(
                        firstText: "Flutter DB",
                        secondText: "Passenger",
                        alignment: CrossAxisAlignment.start,
                        isColor: false,

                      ),
                      AppColumnLayout(
                        firstText: "5221 364869",
                        secondText: "Password",
                        alignment: CrossAxisAlignment.end,
                        isColor: false,
                      ),

                    ],
                  ),
                  Gap(AppLayout.getHeight(20)),
                  const AppLayoutBuilderWidget(section: 15,isColor: false,width: 5,),
                  Gap(AppLayout.getHeight(20)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children:  const [

                      AppColumnLayout(
                        firstText: "0055 444 77147",
                        secondText: "Number Of E-Ticket",
                        alignment: CrossAxisAlignment.start,
                        isColor: false,

                      ),
                      AppColumnLayout(
                        firstText: "B2SG28",
                        secondText: "Booking Code",
                        alignment: CrossAxisAlignment.end,
                        isColor: false,
                      ),

                    ],
                  ),
                  Gap(AppLayout.getHeight(20)),
                  const AppLayoutBuilderWidget(section: 15,isColor: false,width: 5,),
                  Gap(AppLayout.getHeight(20)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                height:25,
                                width: 90,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image:const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage("img/visa.png"))
                                ),
                              ),
                              Text(" *** 8447",style: Styles.headLineStyle3,)
                            ],
                          ),
                          Gap(AppLayout.getHeight(5)),
                          Text("Payment Method",style: Styles.headLineStyle4,)
                        ],
                      ),
                      AppColumnLayout(
                        firstText: "\$249.99",
                        secondText: "Price",
                        alignment: CrossAxisAlignment.end,
                        isColor: false,

                      ),
                    ],
                  )
                ],
              ),
            ),
            /*
            bar code
             */
            SizedBox(height: 1,),
            Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(AppLayout.getHeight(21)),
                      bottomLeft: Radius.circular(AppLayout.getHeight(21))
                  )
              ),
              margin: EdgeInsets.only(left:AppLayout.getHeight(15),right:AppLayout.getHeight(15) ),
              padding: EdgeInsets.only(top: AppLayout.getHeight(20),bottom: AppLayout.getHeight(20)),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: AppLayout.getWidth(15)),
                child: ClipRRect(
                  borderRadius:BorderRadius.circular(AppLayout.getHeight(14)),
                  child: BarcodeWidget(
                    barcode: Barcode.code128(),
                    data: 'https://github.com/martinovovo',
                    drawText: false,
                    color: Styles.textColor,
                    width: double.infinity,
                    height: 70,
                  ),
                ),
              ),
            ),
            Gap(AppLayout.getHeight(20)),
            Container(
                padding: EdgeInsets.only(left: AppLayout.getHeight(15)),
                child : TicketView(ticket: ticketList[0],)
            ),
            Gap(AppLayout.getHeight(2)),
            //FindTickets
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: AppLayout.getHeight(18),horizontal: AppLayout.getWidth(15)),
                  padding: EdgeInsets.symmetric(vertical: AppLayout.getHeight(18),horizontal: AppLayout.getWidth(15)),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppLayout.getWidth(25)),
                    color: Colors.redAccent,
                    boxShadow: [
                    BoxShadow(
                        blurRadius: 10,
                        spreadRadius: 7,
                        offset: Offset(1, 1),
                        color: Colors.black.withOpacity(0.4)
                    )
                    ]
                  ),
                  child: Center(
                    child:
                    RichText(text: TextSpan(
                      recognizer: TapGestureRecognizer()..onTap=()=>Get.to(CheckOutPage()),
                      text: "Proceed to Book Your Ticket",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,

                      ),
                    )),//Text("Find Tickets",style: Styles.headLineStyle3.copyWith(color: Colors.white),) ,
                  ),
                ),
              ],
            ),

          ],
        ),
        Positioned(
          left: AppLayout.getHeight(19),
          top: AppLayout.getHeight(295),
          child: Container(
            padding: EdgeInsets.all(AppLayout.getHeight(3)),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Styles.textColor,width: 2),
            ),
            child: CircleAvatar(
              maxRadius: 4,
              backgroundColor: Styles.textColor,

            ),
          ),
        ),
        Positioned(
          right: AppLayout.getHeight(19),
          top: AppLayout.getHeight(295),
          child: Container(
            padding: EdgeInsets.all(AppLayout.getHeight(3)),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Styles.textColor,width: 2),
            ),
            child: CircleAvatar(
              maxRadius: 4,
              backgroundColor: Styles.textColor,

            ),
          ),
        ),
      ]
      ),
    );
  }
}
