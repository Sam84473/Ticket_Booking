import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';

import '../utils/app_layout.dart';
import '../utils/app_styles.dart';

class HotelScreen extends StatelessWidget {
  final Map<String,dynamic>hotel;
  const HotelScreen({Key? key,required this.hotel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('hotel prize is ${hotel['place']}');
    final size = AppLayout.getSize(context);
    return Container(
      width: size.width*0.6,
      height: AppLayout.getHeight(350),
      padding: EdgeInsets.symmetric(horizontal: AppLayout.getWidth(10) ,vertical: AppLayout.getHeight(17) ),
      margin: const EdgeInsets.only(right: 17,top: 5),
      decoration: BoxDecoration(
          color: Styles.primaryColor,
          borderRadius: BorderRadius.circular(AppLayout.getHeight(24)),
          boxShadow: [ BoxShadow(
            color: Colors.grey.shade200,
            blurRadius: 20,
            spreadRadius: 1,
          ),

          ]
      ),
      child: Column(
        children: [
          Container(
            height: AppLayout.getHeight(180),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppLayout.getHeight(12)),
              color: Styles.primaryColor,
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage("img/${hotel['image']}")),

            ),
          ),
          Gap(AppLayout.getHeight(10)),
          Text(hotel['place'],style: Styles.headLineStyle2.copyWith(color: Colors.grey.shade400),),
          Gap(AppLayout.getHeight(5)),
          Text(hotel['destination'],style: Styles.headLineStyle3.copyWith(color: Colors.white),),
          Gap(AppLayout.getHeight(8)),
          Text("\$${hotel['price']}/night",style: Styles.headLineStyle1.copyWith(color: Colors.grey.shade400),)

        ],
      ),

    );
  }
}
