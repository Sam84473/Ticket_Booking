import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

class AppLayout {
  static getSize(BuildContext contex){
    return MediaQuery.of(contex).size;
  }
  static getScreenHeight(){
    return Get.height;
  }
  static getScreenWidth(){
    return Get.width;
  }
  static getHeight(double pixel){
    double x = getScreenHeight()/pixel;
    return getScreenHeight()/x;

  }
  static getWidth(double pixel) {
    double y = getScreenWidth() / pixel;
    return getScreenWidth() / y;
  }
}