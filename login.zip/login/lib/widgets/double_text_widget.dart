import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../utils/app_styles.dart';

class AppDoubleTextWidget extends StatelessWidget {
  final String text;
  final String smallText;
  const AppDoubleTextWidget({Key? key,required this.text,required this.smallText}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return   Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(text,style: Styles.headLineStyle2,),
        InkWell(
            onTap: (){
              print("view all is tapped");
            },
            child: Text(smallText,style: Styles.textStyle.copyWith(color: primary),))
      ],
    );
  }
}
